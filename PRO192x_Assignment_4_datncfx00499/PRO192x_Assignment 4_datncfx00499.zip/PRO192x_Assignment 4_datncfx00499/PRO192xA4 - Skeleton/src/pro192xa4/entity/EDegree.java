/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pro192xa4.entity;

//enumerate degree level of a teacher
public enum EDegree {    
    BACHELOR, MASTER, DOCTOR
}
