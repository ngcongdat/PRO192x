JDK & JRE:
Java� Platform, Standard Edition 8 Development Kit
Java� Platform, Standard Edition 8 Runtime Environment
Setup:
Eclipse IDE for Java Developers
Version: 23-05-2018 (4.8.0)

================================================================
- Open Eclipse
- Open folder "PRO192x_Assignment 4_datncfx00499" from File System
- Open PRO192xA4 - Skeleton -> src -> pro192xa3.ui -> PRO192xA4.java
- Right click -> Run As -> 1 Java Application
